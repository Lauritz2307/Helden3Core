package de.helden3.mod;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.GameType;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Mod(Helden3Core.MOD_ID)
public final class Helden3Core {
    public static final String MOD_ID = "helden3core";
    private static final long COMBAT_TAG_MS = 15_000L;
    private static final Map<UUID, Long> combatUntil = new HashMap<>();
    private static final Map<UUID, Integer> hearts = new HashMap<>();
    private static final Map<UUID, Integer> bounties = new HashMap<>();

    public Helden3Core() { MinecraftForge.EVENT_BUS.register(this); }

    private static void applyHearts(ServerPlayer player) {
        int count = hearts.computeIfAbsent(player.getUUID(), ignored -> 3);
        var attribute = player.getAttribute(Attributes.MAX_HEALTH);
        if (attribute != null) attribute.setBaseValue(Math.max(0, count) * 2.0);
        if (count > 0 && player.getHealth() > count * 2.0f) player.setHealth(count * 2.0f);
        if (count <= 0) {
            player.setGameMode(GameType.SPECTATOR);
            player.sendSystemMessage(Component.literal("Du bist eliminiert (0 Herzen). Ein Admin kann dich mit /helden3 revive wiederbeleben."));
        }
    }

    @SubscribeEvent public void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) applyHearts(player);
    }

    @SubscribeEvent public void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) applyHearts(player);
    }

    @SubscribeEvent public void onHurt(LivingHurtEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer victim)) return;
        if (event.getSource().getEntity() instanceof ServerPlayer attacker && attacker != victim) {
            long expiry = System.currentTimeMillis() + COMBAT_TAG_MS;
            combatUntil.put(victim.getUUID(), expiry);
            combatUntil.put(attacker.getUUID(), expiry);
            victim.sendSystemMessage(Component.literal("§cKampf! Logout-Strafe für 15 Sekunden aktiv."));
            attacker.sendSystemMessage(Component.literal("§cKampf! Logout-Strafe für 15 Sekunden aktiv."));
        }
    }

    @SubscribeEvent public void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            Long expiry = combatUntil.remove(player.getUUID());
            if (expiry != null && expiry > System.currentTimeMillis()) {
                // Apply the logout penalty immediately and notify the server. This avoids relying on a
                // disconnected player entity remaining alive after logout.
                int remaining = Math.max(0, hearts.getOrDefault(player.getUUID(), 3) - 1);
                hearts.put(player.getUUID(), remaining);
                MinecraftServer server = player.getServer();
                if (server != null) server.getPlayerList().broadcastSystemMessage(
                    Component.literal("§4[Helden 3] " + player.getGameProfile().getName() + " hat sich im Kampf ausgeloggt und verliert ein Herz!"), false);
                combatUntil.remove(player.getUUID());
            }
        }
    }

    @SubscribeEvent public void onDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer victim)) return;
        UUID id = victim.getUUID();
        int remaining = Math.max(0, hearts.getOrDefault(id, 3) - 1);
        hearts.put(id, remaining);
        applyHearts(victim);
        if (event.getSource().getEntity() instanceof ServerPlayer killer && !killer.getUUID().equals(id)) {
            int bounty = bounties.getOrDefault(id, 0);
            if (bounty > 0) {
                bounties.remove(id);
                killer.sendSystemMessage(Component.literal("§6Kopfgeld kassiert: " + bounty + " Punkte für " + victim.getGameProfile().getName() + "! (Prototyp: Punkte werden nicht als Geld gutgeschrieben.)"));
                victim.getServer().getPlayerList().broadcastSystemMessage(Component.literal("§6" + killer.getGameProfile().getName() + " hat das Kopfgeld auf " + victim.getGameProfile().getName() + " eingelöst!"), false);
            }
        }
        combatUntil.remove(id);
    }

    @SubscribeEvent public void onCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("helden3")
            .then(Commands.literal("bounty")
                .then(Commands.argument("spieler", StringArgumentType.word())
                    .then(Commands.argument("punkte", IntegerArgumentType.integer(1, 1_000_000))
                        .requires(src -> src.hasPermission(0))
                        .executes(ctx -> {
                            ServerPlayer target = findPlayer(ctx.getSource(), StringArgumentType.getString(ctx, "spieler"));
                            if (target == null) return 0;
                            int amount = IntegerArgumentType.getInteger(ctx, "punkte");
                            bounties.merge(target.getUUID(), amount, Integer::sum);
                            ctx.getSource().sendSuccess(() -> Component.literal("Kopfgeld auf " + target.getGameProfile().getName() + ": " + bounties.get(target.getUUID()) + " Punkte."), false);
                            target.sendSystemMessage(Component.literal("§6Auf dich wurde ein Kopfgeld von " + amount + " Punkten ausgesetzt!"));
                            return 1;
                        }))))
            .then(Commands.literal("hearts")
                .requires(src -> src.hasPermission(2))
                .then(Commands.argument("spieler", StringArgumentType.word())
                    .then(Commands.argument("anzahl", IntegerArgumentType.integer(0, 100))
                        .executes(ctx -> {
                            ServerPlayer target = findPlayer(ctx.getSource(), StringArgumentType.getString(ctx, "spieler"));
                            if (target == null) return 0;
                            hearts.put(target.getUUID(), IntegerArgumentType.getInteger(ctx, "anzahl"));
                            applyHearts(target);
                            ctx.getSource().sendSuccess(() -> Component.literal("Herzen aktualisiert."), true);
                            return 1;
                        }))))
            .then(Commands.literal("revive").requires(src -> src.hasPermission(2))
                .then(Commands.argument("spieler", StringArgumentType.word()).executes(ctx -> {
                    ServerPlayer target = findPlayer(ctx.getSource(), StringArgumentType.getString(ctx, "spieler"));
                    if (target == null) return 0;
                    hearts.put(target.getUUID(), 3);
                    target.setGameMode(GameType.SURVIVAL);
                    applyHearts(target);
                    target.setHealth(6.0f);
                    ctx.getSource().sendSuccess(() -> Component.literal(target.getGameProfile().getName() + " wurde mit 3 Herzen wiederbelebt."), true);
                    return 1;
                })))
            .then(Commands.literal("status").executes(ctx -> {
                if (ctx.getSource().getEntity() instanceof ServerPlayer p) {
                    ctx.getSource().sendSuccess(() -> Component.literal("Herzen: " + hearts.getOrDefault(p.getUUID(), 3) + " | Kopfgeld auf dich: " + bounties.getOrDefault(p.getUUID(), 0)), false);
                    return 1;
                }
                ctx.getSource().sendFailure(Component.literal("Nur Spieler können diesen Befehl nutzen.")); return 0;
            })));
    }

    private static ServerPlayer findPlayer(CommandSourceStack source, String name) {
        ServerPlayer target = source.getServer().getPlayerList().getPlayerByName(name);
        if (target == null) source.sendFailure(Component.literal("Spieler muss online sein: " + name));
        return target;
    }
}
