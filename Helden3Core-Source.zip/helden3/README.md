# Helden 3 Core (Forge 1.21.11)

Eigenes Forge-Mod-Projekt mit Java 21.

## Enthalten (Prototyp)
- Start mit 3 Herzen (6 HP)
- PvP-Kampfmarkierung für 15 Sekunden
- Logout im Kampf: ein Herz Verlust und Servermeldung
- Tod: ein Herz Verlust
- Kopfgeld setzen und beim Töten des Ziels auslösen
- `/helden3 status`
- Admin: `/helden3 hearts <spieler> <anzahl>` und `/helden3 revive <spieler>`
- Kopfgeld: `/helden3 bounty <spieler> <punkte>`

## Wichtig: Prototyp-Status
Dies ist Quellcode, noch keine fertig kompilierte und getestete JAR. Die Herz- und Kopfgelddaten liegen derzeit nur im Arbeitsspeicher und werden bei einem Serverneustart zurückgesetzt. Das Kopfgeld verwendet Punkte als Prototyp-Währung; es ist noch nicht an ein Economy-System angebunden. Vor einem öffentlichen Einsatz sollte das Projekt kompiliert, getestet und um persistente Speicherung ergänzt werden.

## Bauen
Voraussetzungen: Java 21 und Gradle 8.x. Im Projektordner ausführen:

- Windows: `gradle build`
- Linux/macOS: `gradle build`

Die Mod-JAR liegt nach erfolgreichem Build unter `build/libs/helden3core-1.0.0.jar`.

Minecraft-Version: 1.21.11; Forge MDK dependency: `1.21.11-61.2.0`.
