package com.helden.hearts.event;

import com.helden.hearts.HeldenHearts;
import com.helden.hearts.config.HeldenConfig;
import com.helden.hearts.data.HeartData;
import com.helden.hearts.data.HeartManager;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class HeartEvents {

    @SubscribeEvent
    public void onPlayerJoin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (player.getServer() == null) return;

        HeartManager manager = HeartManager.get(player.getServer());
        HeartData data = manager.getOrCreate(player);

        player.sendSystemMessage(Component.literal(
                "§6[Helden Hearts] §fDu hast §c" + data.getHearts() + " §fHerzen."));
    }

    @SubscribeEvent
    public void onPlayerDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (player.getServer() == null) return;

        if (HeldenConfig.SERVER.onlyPvpLosesHeart.get()) {
            Entity source = event.getSource().getEntity();
            if (!(source instanceof Player) || source == player) {
                return;
            }
        }

        HeartManager manager = HeartManager.get(player.getServer());
        HeartData data = manager.getOrCreate(player);

        boolean removed = manager.removeHeart(player);

        if (removed) {
            int remaining = data.getHearts();
            String msg = String.format(HeldenConfig.SERVER.heartLostMessage.get(), remaining);
            player.sendSystemMessage(Component.literal(msg));

            HeldenHearts.LOGGER.info("{} hat ein Herz verloren. Verbleibend: {}",
                    player.getName().getString(), remaining);

            if (remaining <= 0) {
                handleZeroHearts(player);
            }
        }

        manager.clearCombat(player);
    }

    private void handleZeroHearts(ServerPlayer player) {
        if (HeldenConfig.SERVER.banOnZeroHearts.get()) {
            String banMsg = HeldenConfig.SERVER.banMessage.get();
            player.getServer().getPlayerList().getBans().add(
                    new net.minecraft.server.players.UserBanListEntry(
                            player.getGameProfile(),
                            null,
                            "HeldenHearts",
                            null,
                            banMsg
                    )
            );
            player.connection.disconnect(Component.literal(banMsg));
            HeldenHearts.LOGGER.info("{} wurde wegen 0 Herzen gebannt.", player.getName().getString());
        } else {
            player.setGameMode(net.minecraft.world.level.GameType.SPECTATOR);
            player.sendSystemMessage(Component.literal(
                    "§cDu hast alle Herzen verloren und bist jetzt Spectator."));
        }
    }
}
