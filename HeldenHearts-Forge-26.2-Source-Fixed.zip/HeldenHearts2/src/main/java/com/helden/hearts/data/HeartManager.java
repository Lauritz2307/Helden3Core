package com.helden.hearts.data;

import com.helden.hearts.config.HeldenConfig;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.storage.DimensionDataStorage;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class HeartManager extends SavedData {

    private static final String DATA_NAME = "helden_hearts";

    private final Map<UUID, HeartData> playerData = new HashMap<>();

    public HeartManager() {
    }

    public static HeartManager get(MinecraftServer server) {
        ServerLevel overworld = server.overworld();
        DimensionDataStorage storage = overworld.getDataStorage();
        return storage.computeIfAbsent(HeartManager::load, HeartManager::new, DATA_NAME);
    }

    public HeartData getOrCreate(ServerPlayer player) {
        return playerData.computeIfAbsent(player.getUUID(),
                uuid -> HeartData.createDefault(player, HeldenConfig.SERVER.maxHearts.get()));
    }

    public HeartData get(UUID uuid) {
        return playerData.get(uuid);
    }

    public void setHearts(ServerPlayer player, int amount) {
        HeartData data = getOrCreate(player);
        data.setHearts(Math.min(amount, HeldenConfig.SERVER.maxHearts.get()));
        setDirty();
    }

    public boolean removeHeart(ServerPlayer player) {
        HeartData data = getOrCreate(player);
        boolean removed = data.removeHeart();
        setDirty();
        return removed;
    }

    public void startCombat(ServerPlayer player) {
        HeartData data = getOrCreate(player);
        data.startCombat(HeldenConfig.SERVER.combatDurationSeconds.get());
        setDirty();
    }

    public void clearCombat(ServerPlayer player) {
        HeartData data = getOrCreate(player);
        data.clearCombat();
        setDirty();
    }

    public boolean isInCombat(ServerPlayer player) {
        HeartData data = getOrCreate(player);
        return data.isInCombat();
    }

    public Map<UUID, HeartData> getAll() {
        return playerData;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (HeartData data : playerData.values()) {
            list.add(data.save());
        }
        tag.put("Players", list);
        return tag;
    }

    public static HeartManager load(CompoundTag tag) {
        HeartManager manager = new HeartManager();
        ListTag list = tag.getList("Players", Tag.TAG_COMPOUND);
        int defaultHearts = HeldenConfig.SERVER.maxHearts.get();
        for (int i = 0; i < list.size(); i++) {
            CompoundTag playerTag = list.getCompound(i);
            HeartData data = HeartData.load(playerTag, defaultHearts);
            manager.playerData.put(data.getPlayerId(), data);
        }
        return manager;
    }
}
