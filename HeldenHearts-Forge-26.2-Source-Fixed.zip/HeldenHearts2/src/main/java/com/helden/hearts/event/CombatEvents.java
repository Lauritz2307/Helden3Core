package com.helden.hearts.event;

import com.helden.hearts.HeldenHearts;
import com.helden.hearts.config.HeldenConfig;
import com.helden.hearts.data.HeartData;
import com.helden.hearts.data.HeartManager;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CombatEvents {

    private final Map<UUID, Integer> lastShownSeconds = new HashMap<>();

    @SubscribeEvent
    public void onPlayerAttack(LivingAttackEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer victim)) return;
        if (victim.getServer() == null) return;

        DamageSource source = event.getSource();
        Entity attackerEntity = source.getEntity();

        if (!(attackerEntity instanceof ServerPlayer attacker)) return;
        if (attacker == victim) return;

        HeartManager manager = HeartManager.get(victim.getServer());

        boolean wasInCombat = manager.isInCombat(victim);
        manager.startCombat(victim);
        manager.startCombat(attacker);

        if (!wasInCombat && HeldenConfig.SERVER.showCombatTimeInActionBar.get()) {
            victim.sendSystemMessage(Component.literal(HeldenConfig.SERVER.combatStartMessage.get()));
            attacker.sendSystemMessage(Component.literal(HeldenConfig.SERVER.combatStartMessage.get()));
        }
    }

    @SubscribeEvent
    public void onPlayerLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (player.getServer() == null) return;
        if (!HeldenConfig.SERVER.logoutDuringCombatKills.get()) return;

        HeartManager manager = HeartManager.get(player.getServer());
        if (!manager.isInCombat(player)) return;

        HeldenHearts.LOGGER.info("{} hat während Combat ausgeloggt – Herzverlust!",
                player.getName().getString());

        boolean removed = manager.removeHeart(player);
        manager.clearCombat(player);

        if (removed) {
            HeartData data = manager.getOrCreate(player);
            if (data.getHearts() <= 0) {
                if (HeldenConfig.SERVER.banOnZeroHearts.get()) {
                    String banMsg = HeldenConfig.SERVER.banMessage.get() + " (Combat-Logout)";
                    player.getServer().getPlayerList().getBans().add(
                            new net.minecraft.server.players.UserBanListEntry(
                                    player.getGameProfile(),
                                    null,
                                    "HeldenHearts-CombatLogout",
                                    null,
                                    banMsg
                            )
                    );
                }
            }
        }
    }

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!HeldenConfig.SERVER.showCombatTimeInActionBar.get()) return;

        if (event.getServer().getTickCount() % 20 != 0) return;

        for (ServerPlayer player : event.getServer().getPlayerList().getPlayers()) {
            HeartManager manager = HeartManager.get(event.getServer());
            HeartData data = manager.getOrCreate(player);

            if (data.isInCombat()) {
                int seconds = data.getCombatRemainingSeconds();
                Integer last = lastShownSeconds.get(player.getUUID());
                if (last == null || last != seconds) {
                    player.displayClientMessage(
                            Component.literal("§c⚔ Combat: §e" + seconds + "s §cverbleibend"),
                            true
                    );
                    lastShownSeconds.put(player.getUUID(), seconds);
                }
            } else {
                lastShownSeconds.remove(player.getUUID());
            }
        }
    }
}
