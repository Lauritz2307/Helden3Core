package com.helden.hearts;

import com.helden.hearts.command.HeartsCommands;
import com.helden.hearts.config.HeldenConfig;
import com.helden.hearts.event.CombatEvents;
import com.helden.hearts.event.HeartEvents;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(HeldenHearts.MOD_ID)
public class HeldenHearts {

    public static final String MOD_ID = "heldenhearts";
    public static final Logger LOGGER = LogManager.getLogger();

    public HeldenHearts() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        modBus.addListener(this::commonSetup);

        ModLoadingContext.get().registerConfig(ModConfig.Type.SERVER, HeldenConfig.SERVER_SPEC);

        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(new HeartEvents());
        MinecraftForge.EVENT_BUS.register(new CombatEvents());
        MinecraftForge.EVENT_BUS.addListener(this::onRegisterCommands);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        LOGGER.info("Helden Hearts geladen – 3-Herzen-System + Combat-Logger aktiv");
    }

    private void onRegisterCommands(RegisterCommandsEvent event) {
        HeartsCommands.register(event.getDispatcher());
    }
}
