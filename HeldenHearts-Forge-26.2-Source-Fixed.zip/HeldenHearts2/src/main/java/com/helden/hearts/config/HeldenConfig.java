package com.helden.hearts.config;

import net.minecraftforge.common.ForgeConfigSpec;

public class HeldenConfig {

    public static final ForgeConfigSpec SERVER_SPEC;
    public static final Server SERVER;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();
        SERVER = new Server(builder);
        SERVER_SPEC = builder.build();
    }

    public static class Server {
        public final ForgeConfigSpec.IntValue maxHearts;
        public final ForgeConfigSpec.IntValue combatDurationSeconds;
        public final ForgeConfigSpec.BooleanValue onlyPvpLosesHeart;
        public final ForgeConfigSpec.BooleanValue banOnZeroHearts;
        public final ForgeConfigSpec.BooleanValue showCombatTimeInActionBar;
        public final ForgeConfigSpec.BooleanValue allowHeartTrading;
        public final ForgeConfigSpec.BooleanValue logoutDuringCombatKills;
        public final ForgeConfigSpec.ConfigValue<String> banMessage;
        public final ForgeConfigSpec.ConfigValue<String> heartLostMessage;
        public final ForgeConfigSpec.ConfigValue<String> combatStartMessage;

        public Server(ForgeConfigSpec.Builder builder) {
            builder.comment("Helden Hearts – Server Einstellungen").push("general");

            maxHearts = builder
                    .comment("Maximale Anzahl an Herzen pro Spieler")
                    .defineInRange("maxHearts", 3, 1, 20);

            combatDurationSeconds = builder
                    .comment("Dauer des Combat-Timers in Sekunden")
                    .defineInRange("combatDurationSeconds", 30, 5, 300);

            onlyPvpLosesHeart = builder
                    .comment("Nur PvP-Tode (durch anderen Spieler) kosten ein Herz")
                    .define("onlyPvpLosesHeart", true);

            banOnZeroHearts = builder
                    .comment("Spieler bei 0 Herzen permanent bannen (sonst Spectator)")
                    .define("banOnZeroHearts", true);

            showCombatTimeInActionBar = builder
                    .comment("Verbleibende Combat-Zeit in der Actionbar anzeigen")
                    .define("showCombatTimeInActionBar", true);

            allowHeartTrading = builder
                    .comment("Erlaubt Spielern, Herzen mit /hearts give zu verschenken")
                    .define("allowHeartTrading", true);

            logoutDuringCombatKills = builder
                    .comment("Ausloggen während Combat = sofortiger Tod + Herzverlust")
                    .define("logoutDuringCombatKills", true);

            banMessage = builder
                    .comment("Nachricht beim Ban wegen 0 Herzen")
                    .define("banMessage", "§cDu hast alle deine Herzen verloren und wurdest gebannt!");

            heartLostMessage = builder
                    .comment("Nachricht wenn ein Herz verloren wird (%s = verbleibende Herzen)")
                    .define("heartLostMessage", "§cDu hast ein Herz verloren! Verbleibend: §e%s");

            combatStartMessage = builder
                    .comment("Nachricht wenn Combat beginnt")
                    .define("combatStartMessage", "§6Du bist jetzt im Kampf! Ausloggen kostet ein Herz.");

            builder.pop();
        }
    }
}
