package com.helden.hearts.command;

import com.helden.hearts.config.HeldenConfig;
import com.helden.hearts.data.HeartData;
import com.helden.hearts.data.HeartManager;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

public class HeartsCommands {

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(
                Commands.literal("hearts")
                        .requires(source -> source.hasPermission(0))
                        .then(Commands.literal("get")
                                .executes(ctx -> getOwnHearts(ctx))
                                .then(Commands.argument("player", EntityArgument.player())
                                        .requires(source -> source.hasPermission(2))
                                        .executes(ctx -> getHearts(ctx, EntityArgument.getPlayer(ctx, "player")))))
                        .then(Commands.literal("set")
                                .requires(source -> source.hasPermission(2))
                                .then(Commands.argument("player", EntityArgument.player())
                                        .then(Commands.argument("amount", IntegerArgumentType.integer(0, 20))
                                                .executes(ctx -> setHearts(ctx,
                                                        EntityArgument.getPlayer(ctx, "player"),
                                                        IntegerArgumentType.getInteger(ctx, "amount"))))))
                        .then(Commands.literal("give")
                                .then(Commands.argument("player", EntityArgument.player())
                                        .executes(ctx -> giveHeart(ctx, EntityArgument.getPlayer(ctx, "player")))))
                        .then(Commands.literal("add")
                                .requires(source -> source.hasPermission(2))
                                .then(Commands.argument("player", EntityArgument.player())
                                        .then(Commands.argument("amount", IntegerArgumentType.integer(1, 20))
                                                .executes(ctx -> addHearts(ctx,
                                                        EntityArgument.getPlayer(ctx, "player"),
                                                        IntegerArgumentType.getInteger(ctx, "amount"))))))
                        .then(Commands.literal("combat")
                                .requires(source -> source.hasPermission(2))
                                .then(Commands.argument("player", EntityArgument.player())
                                        .executes(ctx -> forceCombat(ctx, EntityArgument.getPlayer(ctx, "player")))))
                        .then(Commands.literal("reload")
                                .requires(source -> source.hasPermission(2))
                                .executes(ctx -> {
                                    ctx.getSource().sendSuccess(() -> Component.literal(
                                            "§aHelden Hearts Config ist serverconfig – nutze /reload"), true);
                                    return 1;
                                }))
        );
    }

    private static int getOwnHearts(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = ctx.getSource().getPlayerOrException();
        return getHearts(ctx, player);
    }

    private static int getHearts(CommandContext<CommandSourceStack> ctx, ServerPlayer target) {
        HeartManager manager = HeartManager.get(target.getServer());
        HeartData data = manager.getOrCreate(target);

        String combatInfo = data.isInCombat()
                ? " §7(Combat: " + data.getCombatRemainingSeconds() + "s)"
                : "";

        ctx.getSource().sendSuccess(() -> Component.literal(
                "§6[Helden] §f" + target.getName().getString() + " hat §c" + data.getHearts() +
                        " §fHerz(en)" + combatInfo), false);
        return data.getHearts();
    }

    private static int setHearts(CommandContext<CommandSourceStack> ctx, ServerPlayer target, int amount) {
        HeartManager manager = HeartManager.get(target.getServer());
        manager.setHearts(target, amount);

        ctx.getSource().sendSuccess(() -> Component.literal(
                "§aHerzen von " + target.getName().getString() + " auf §c" + amount + " §agesetzt."), true);
        target.sendSystemMessage(Component.literal(
                "§6Deine Herzen wurden auf §c" + amount + " §6gesetzt."));
        return amount;
    }

    private static int addHearts(CommandContext<CommandSourceStack> ctx, ServerPlayer target, int amount) {
        HeartManager manager = HeartManager.get(target.getServer());
        HeartData data = manager.getOrCreate(target);
        int newAmount = Math.min(data.getHearts() + amount, HeldenConfig.SERVER.maxHearts.get());
        manager.setHearts(target, newAmount);

        ctx.getSource().sendSuccess(() -> Component.literal(
                "§a" + amount + " Herz(en) zu " + target.getName().getString() + " hinzugefügt. Jetzt: §c" + newAmount), true);
        return newAmount;
    }

    private static int giveHeart(CommandContext<CommandSourceStack> ctx, ServerPlayer target) throws CommandSyntaxException {
        if (!HeldenConfig.SERVER.allowHeartTrading.get()) {
            ctx.getSource().sendFailure(Component.literal("§cHerz-Tausch ist deaktiviert."));
            return 0;
        }

        ServerPlayer giver = ctx.getSource().getPlayerOrException();
        if (giver == target) {
            ctx.getSource().sendFailure(Component.literal("§cDu kannst dir selbst kein Herz geben."));
            return 0;
        }

        HeartManager manager = HeartManager.get(giver.getServer());
        HeartData giverData = manager.getOrCreate(giver);

        if (giverData.getHearts() <= 1) {
            ctx.getSource().sendFailure(Component.literal("§cDu brauchst mindestens 2 Herzen, um eines zu verschenken."));
            return 0;
        }

        manager.removeHeart(giver);
        HeartData targetData = manager.getOrCreate(target);
        int max = HeldenConfig.SERVER.maxHearts.get();
        if (targetData.getHearts() < max) {
            targetData.addHeart();
            manager.setDirty();
        }

        giver.sendSystemMessage(Component.literal(
                "§aDu hast §c1 Herz §aan " + target.getName().getString() + " gegeben."));
        target.sendSystemMessage(Component.literal(
                "§aDu hast §c1 Herz §avon " + giver.getName().getString() + " erhalten!"));
        return 1;
    }

    private static int forceCombat(CommandContext<CommandSourceStack> ctx, ServerPlayer target) {
        HeartManager manager = HeartManager.get(target.getServer());
        manager.startCombat(target);
        ctx.getSource().sendSuccess(() -> Component.literal(
                "§aCombat für " + target.getName().getString() + " gestartet."), true);
        target.sendSystemMessage(Component.literal(HeldenConfig.SERVER.combatStartMessage.get()));
        return 1;
    }
}
