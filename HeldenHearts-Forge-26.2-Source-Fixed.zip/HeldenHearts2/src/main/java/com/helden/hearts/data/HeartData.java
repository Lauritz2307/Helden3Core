package com.helden.hearts.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;

import java.util.UUID;

public class HeartData {

    private final UUID playerId;
    private int hearts;
    private long combatEndTime;
    private boolean linked;

    public HeartData(UUID playerId, int startingHearts) {
        this.playerId = playerId;
        this.hearts = startingHearts;
        this.combatEndTime = 0L;
        this.linked = false;
    }

    public UUID getPlayerId() {
        return playerId;
    }

    public int getHearts() {
        return hearts;
    }

    public void setHearts(int hearts) {
        this.hearts = Math.max(0, hearts);
    }

    public void addHeart() {
        this.hearts++;
    }

    public boolean removeHeart() {
        if (this.hearts <= 0) return false;
        this.hearts--;
        return true;
    }

    public boolean isInCombat() {
        return combatEndTime > System.currentTimeMillis();
    }

    public long getCombatRemainingMillis() {
        return Math.max(0, combatEndTime - System.currentTimeMillis());
    }

    public int getCombatRemainingSeconds() {
        return (int) (getCombatRemainingMillis() / 1000);
    }

    public void startCombat(int durationSeconds) {
        this.combatEndTime = System.currentTimeMillis() + (durationSeconds * 1000L);
    }

    public void clearCombat() {
        this.combatEndTime = 0L;
    }

    public boolean isLinked() {
        return linked;
    }

    public void setLinked(boolean linked) {
        this.linked = linked;
    }

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        tag.putUUID("PlayerId", playerId);
        tag.putInt("Hearts", hearts);
        tag.putLong("CombatEnd", combatEndTime);
        tag.putBoolean("Linked", linked);
        return tag;
    }

    public static HeartData load(CompoundTag tag, int defaultHearts) {
        UUID id = tag.getUUID("PlayerId");
        HeartData data = new HeartData(id, defaultHearts);
        data.hearts = tag.getInt("Hearts");
        data.combatEndTime = tag.getLong("CombatEnd");
        data.linked = tag.getBoolean("Linked");
        return data;
    }

    public static HeartData createDefault(ServerPlayer player, int defaultHearts) {
        return new HeartData(player.getUUID(), defaultHearts);
    }
}
