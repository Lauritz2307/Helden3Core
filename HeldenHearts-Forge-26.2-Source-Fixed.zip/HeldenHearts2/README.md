# Helden Hearts – Forge 26.2 (korrigierte Version)

3-Herzen-System + Combat-Logger für Minecraft 26.2.

## Wichtigste Änderung
- Gradle auf **8.10.2** festgelegt (Gradle 9 wird von Forge noch nicht unterstützt)

## So baust du die Mod in IntelliJ

1. Alten HeldenHearts-Ordner löschen oder umbenennen
2. Dieses neue ZIP entpacken
3. In IntelliJ öffnen (File → Open)
4. Trust Project
5. Warten bis Gradle Sync fertig ist
6. Rechts im Gradle-Fenster: Tasks → build → build (Doppelklick)

Die fertige JAR liegt danach in:
`build/libs/heldenhearts-1.0.0.jar`
